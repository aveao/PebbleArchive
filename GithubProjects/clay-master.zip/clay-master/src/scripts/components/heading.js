'use strict';

module.exports = {
  name: 'heading',
  template: require('../../templates/components/heading.tpl'),
  manipulator: 'html',
  defaults: {
    size: 4
  }
};
