from django.contrib import admin
from ide.models import Project

admin.site.register(Project)
