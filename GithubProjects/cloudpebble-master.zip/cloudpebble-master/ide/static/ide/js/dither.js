/**
 * Created by katharine on 19/03/2014.
 */

(function() {
    CloudPebble.ImageDither = function(blob) {

    };
})();