Translation
===========

Hello translators!

Thank you for your interest in helping to translate CloudPebble.

However, please do not edit files here directly. We use POEditor to manage translations. Please visit
[this link](https://poeditor.com/join/project?hash=73317823931c537d4a31b43bdb7b3725) to help out!
