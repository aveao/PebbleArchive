__author__ = 'katharine'

ARM_CS_TOOLS = '' # By default we try the path. Set this to try something else.
