Special thanks to the following for helping to translate CloudPebble:

## French
- Jnm
- Grégoire Sage
- Romain Lespinasse
- CHARAVNER
- Allanco2
- Denis
- Martial Lienert
- Thomas Sarlandie

## German
- Marcel Jackwerth
- Hannes Güdelhöfer

## Spanish
- David Rodríguez Rincón
- Jaime
- Daniel Rodríguez Troitino
- Thomas Hunsaker
- Antonio Calatrava
