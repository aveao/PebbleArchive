---
name: fctx-demo
creator: JR Mobley
license: mit
link: https://github.com/jrmobley/pebble-fctx-demo
language: c
tags:
  - watchapp
  - graphics
---
Demonstration app for the [fctx](https://github.com/jrmobley/pebble-fctx) library and [fctx-compiler](https://github.com/jrmobley/pebble-fctx-compiler) tool.

![Demo](http://jrmobley.github.io/pebble-fctx-demo/images/fctx-demo-aa.gif)
