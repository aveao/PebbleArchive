---
name: HeroBoard
creator: Rodrigo Mesquita
license: mit
link: https://github.com/rmesquit/HeroBoard
language: c
appstore: 54f3398f2af981c827000058
tags:
  - watchapps
  - graphics
  - animation
---
Guitar Hero-based keyboard for Pebble

This is a Pebble app keyboard based on the game Guitar Hero. It is NOT a final product/watchapp. It is meant to be used with T3/T9 text prediction scripts. When complete, it could be implemented as an exclusive keyboard for Pebble.
