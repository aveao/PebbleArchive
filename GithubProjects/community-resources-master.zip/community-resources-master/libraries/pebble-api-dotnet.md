---
name: Pebble Timeline API for DotNet (C#)
creator: Rob Chartier
license: mit
link: https://github.com/nothingmn/pebble-api-dotnet
language: c#
tags:
	- timeline
---

A Portable Class Library written in C# for sending Timeline Pins for the Pebble watch.
