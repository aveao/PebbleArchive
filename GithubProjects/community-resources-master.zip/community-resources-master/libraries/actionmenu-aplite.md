---
name: ActionMenu Aplite
creator: Grégoire Sage
license: mit
link: https://github.com/gregoiresage/action_menu_aplite
language: c
---

ActionMenu API for aplite (Pebble SDK 2.0)

## Usage

It is the same API as basalt one : http://developer.getpebble.com/docs/c/User_Interface/Window/ActionMenu

## Advantage

Same code for Basalt and Aplite :-)