---
name: pebble-font-list
creator: Johannes Neubrand
description: A more complete list of fonts
link: https://jneubrand.github.io/pebble-font-list/
---

A more complete list of Pebble's system fonts.

Includes a list of supported emoji, shows which fonts support emoji, and includes some fonts the documentation doesn't (eg gothic size 9)
