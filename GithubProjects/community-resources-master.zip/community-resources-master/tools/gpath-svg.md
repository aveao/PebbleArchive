---
name: GPath.svg
creator: Rajendra Serber
description: SVG to Pebble GPath Converter
link: http://gpathsvg.org
---

Convert standard SVG files to a Pebble GPathInfo array that can be drawn with `gpath_draw_filled` or `gpath_draw_outline`.

