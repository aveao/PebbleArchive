---
name: Pebble Pre-Builder
creator: Alexis Le Provost
link: https://github.com/alekece/pebble-pre-builder
---

Update resources media by scanning Pebble resources folder and generate C header file based on application keys.