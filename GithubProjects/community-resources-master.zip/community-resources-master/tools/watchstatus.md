---
name: Watch Status
creator: Max Bäumle
link: http://watchstat.us
---

Track firmware, app and SDK updates. [@WatchStatus](https://twitter.com/WatchStatus) tweets when a version changes.