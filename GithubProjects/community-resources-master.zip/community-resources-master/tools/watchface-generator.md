---
name: Watchface Generator
creator: Paul Rode
link: http://www.watchface-generator.de
---

Create your own, simple watchface without any coding-skills.

Available features:

- Own background-image
- Analog time
- Digital time with optional custom font
- Date
- Free text
- Battery- and connection-indicator

[![Analog](http://www.watchface-generator.de/v2/watchfaces/20140130/ultra_analog/preview.png)](http://www.watchface-generator.de/v2/watchfaces/20140130/ultra_analog/) [![Analog Square](http://www.watchface-generator.de/wf/20140214/analog/preview.png)](http://www.watchface-generator.de/wf/20140214/analog/) [![Big Time](http://www.watchface-generator.de/wf/20140612/big_kredit_2/preview.png)](http://www.watchface-generator.de/wf/20140612/big_kredit_2/)
