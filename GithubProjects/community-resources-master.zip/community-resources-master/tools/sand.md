---
name: sand
creator: Collin Fair
link: http://sand.cpfx.ca
---

sand lets you remix Pebble apps with new colours, features, and more - no coding required.

![sand screenshot](http://i.imgur.com/d7QAI5f.png)
