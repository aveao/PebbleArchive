---
name: Rock Garden
creator: Collin Fair
link: https://github.com/cpfair/rockgarden
---

Rock Garden lets you patch compiled PBWs to override syscalls, add JS, and change metadata. It's the magic behind [sand](http://sand.cpfx.ca).
