---
name: Appstore Badge Generator
creator: Matthew Tole
link: http://pblweb.com/badge
---

Generate cool badges for your Pebble app that show off how many people **love**
your watchapp or watchface.

Here are some of the different colours and sizes you can use:

![Small Orange Badge](http://pblweb.com/badge/52d30a1d19412b4d84000025/orange/small/)

![Medium Black Badge](http://pblweb.com/badge/52d30a1d19412b4d84000025/black/medium/)

![Large White Badge](http://pblweb.com/badge/52d30a1d19412b4d84000025/white/large/)