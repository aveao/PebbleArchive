---
name: Sublime Text Plugin
creator: James Brooks
link: https://sublime.wbond.net/packages/Pebble
---

Sublime Text plugin with SDK completions and commands.

Compatible with SDK Version 2.7

## Super simple installation

Using [Sublime Package Control](http://sublime.wbond.net) you can search for Pebble and install directly from Sublime.

## Commands

1. `build`
2. `clean`
3. `install`
4. `screenshot`
5. `ping`
