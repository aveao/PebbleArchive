---
name: App Message Bridge
creator: finebyte
link: https://github.com/finebyte/AppMsgBridge
---
Bridge from your native Android app to the Pebble Emulator
