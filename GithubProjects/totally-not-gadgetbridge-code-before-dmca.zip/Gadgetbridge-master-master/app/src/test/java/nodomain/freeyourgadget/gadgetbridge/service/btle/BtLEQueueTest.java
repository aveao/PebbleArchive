package nodomain.freeyourgadget.gadgetbridge.service.btle;

import org.junit.Test;

import nodomain.freeyourgadget.gadgetbridge.test.TestBase;

public class BtLEQueueTest extends TestBase {

    @Override
    public void setUp() throws Exception {
        super.setUp();
    }

    @Override
    public void tearDown() throws Exception {
        super.tearDown();
    }

    @Test
    public void testIsConnected() throws Exception {
        // TODO
    }
}